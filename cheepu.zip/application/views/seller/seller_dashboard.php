<div class="row">
	<div class="col-md-3" align="center">
		<a href="<?= base_url(); ?>seller/shop_products">
		<div align="center" class="socard card card-body d w-75 mt-5" style="background-color: #FBEEC1" > 
				<span class="text-secondary"></br><strong>Your Catalog</strong></span>
		</div>
		</a>
	</div>
	<div class="col-md-3 " align="center">
		<a href="<?= base_url(); ?>admin_zone/add_catogory">
		<div align="center" class="socard card card-body d w-75 mt-5" style="background-color: #FBEEC1" > 
				<span class="text-secondary"><i class="fa fa-2x fa-plus"></i></br><strong>Add Catogories</strong></span>
		</div>
		</a>
	</div>
	<div class="col-md-3" align="center">
		<a href="<?= base_url(); ?>admin_zone/add_sub_catogory">
		<div align="center" class="socard card card-body bg-dark d w-75 mt-5"> 
				<span class="text-white"><i class="fa fa-2x fa-plus"></i></br><strong>Add SubCatogories</strong></span>
		</div>
	</a>
	</div>

	<div class="col-md-3" align="center">
			<a href="<?= base_url(); ?>admin_zone/add_product">
		<div align="center" class="socard card card-body bg-dark d w-75 mt-5"> 
				<span class="text-white"><i class="fa fa-2x fa-plus"></i></br><strong>Add Products</strong></span>
		</div>
	</a>
	</div>	

</div>