
    <div class="panel-group" id="accordion1">
        <?php foreach ($cat_name as $category) :?>
            <div class="panel panel-default ">
                <div class="panel-heading">
                    <h4 class="panel-title">
                        <a class="btn btn-success btn-lg" data-toggle="collapse" data-parent="#accordion1" href="#collapseOne<?= $category->cat_id; ?>"><?=$category->cat_name; 
                        ?>
                        </a>
                    </h4>
                </div>
                <div id="collapseOne<?= $category->cat_id; ?>" class="panel-collapse collapse in">
                    <div class="panel-body">
                    <?php foreach($sub_cat_name as $sub_cat): ?>
                            <?php if($sub_cat->category_id == $category->cat_id ): ?>
                              <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample<?= $sub_cat->sub_category_id ?>" aria-expanded="false" aria-controls="collapseExample<?= $sub_cat->sub_category_id ?>">
                                    <?= $sub_cat->sub_category_name ?>
                                </button><br>
                              
                                <div class="collapse container" id="collapseExample<?= $sub_cat->sub_category_id ?>">
                                  <div class="row">
                                    <?php foreach($products as $product): ?>
                                        <?php if($product->sub_cat_id == $sub_cat->sub_category_id ): ?>

                                  <div class="w3-col l3 m3 s6">    
                                <div class="card"  id="di<?= $product->product_id;?>" >
                                  <div class="card card-header">
                                    <span class=" ml-auto"><button class="btn btn-danger btn-xs reject" id="<?=$product->product_id; ?>"><i class="fa fa-ban"></i>Remove</button></span>
                                  </div>
                                  <img src="<?= base_url();?>assets/img/products/<?=$product->product_image;?>"  class="card-img-top" height="200" >
                                    <div class="card-body">
                                      <form id="addpro<?=$product->product_id; ?>" action="" method="post"> 
                                      <div class="thumb-content" id="matter<?=$product->product_id; ?>" pid="<?=$product->product_id; ?>">
                                        <h5 align="center" style="font-size: 15px"><?=$product->product_name; ?></h5>
                                          <span class="pull-left" ><h5 style="font-size: 15px">
                                            <input type="number" name="price" value="<?=$product->s_p; ?>" style="width: 60px;border: 1px solid blue;" value="" required><i class="fa fa-rupee" style="font-size: 10px"></i>/ <span style="font-size: 10px"><?=$product->type; ?></span></h5></span>
                                            <input type="hidden" name="product_id" value="<?= $product->product_id ?>" required>
                                            <input type="hidden" name="sub_category_id" value="<?= $sub_cat->sub_category_id ?>" required>
                                        </div>
                                      </form>
                                         <input type="submit" id="add<?= $product->product_id;?>" pid="<?=$product->product_id; ?>" class="btn btn-block btn-md  btn-secondary addp" value="Update">                                        
                                      <span>
                                        <button  id="edit<?= $product->product_id;?>" pid="<?=$product->product_id; ?>" class="btn  btn-block btn-md btn-danger editp  " style="display: none;" ><i class="fa fa-pencil"></i> Edit</button>
            
                                      </div>        
                                        </div>
                                      </div>
                                      <?php endif; ?>                                         
                                     <?php endforeach; ?>
                                    </div>  
                                </div>                           
                             <?php endif; ?> 
                      <?php endforeach; ?> 
                    </div>
                </div>
            </div>
             <?php endforeach ; ?> 
        </div>