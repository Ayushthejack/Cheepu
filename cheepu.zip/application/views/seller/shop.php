<!--<div class="col-md-3">
	<div class="card text-center bg-secondary text-white mb-3 mt-3">
		<div class="card-body">
			<h3>Order Received</h3>
			<h1 class="display-4">
			<i class="fa fa-shopping-cart"></i>	6
			</h1>
		</div>
	</div>
</div>  -->
<div class="col-md-6 ml-auto mr-auto">
	<div class="card text-center bg-secondary text-white mb-3 mt-3">
		<div class="card-body">
			<h3>Hey! Welcome Seller</h3>
			<h1 class="display-4">
			<i class="fa fa-shopping-cart"></i>	Time To Establish Your business <strong>Online</strong> With <strong>free of Cost</strong>
			</h1>
		</div>
	</div>
</div>
<div class="col-md-3 ml-auto mr-auto">
	<a href="shop_setup">
<button class="btn btn-outline-success btn-lg">To Get Started...press here</button>
	</a>
</div>