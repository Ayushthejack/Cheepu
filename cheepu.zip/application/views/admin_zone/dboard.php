<div class="area"></div><nav class="main-menu">
            <ul>
                <li>
                    <a href="<?= base_url();?>admin_zone/dboard">
                        <i class="fa fa-home fa-2x"></i>
                        <span class="nav-text">
                            Dashboard
                        </span>
                    </a>
                </li>
                <li class="has-subnav">
                    <a href="<?= base_url();?>admin_zone/add_product">
                        <i class="fa fa-laptop fa-2x"></i>
                        <span class="nav-text">
                            Add Products
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="<?= base_url();?>admin_zone/add_catogory">
                       <i class="fa fa-list fa-2x"></i>
                        <span class="nav-text">
                            Add Catogory
                        </span>
                    </a>
                    
                </li>
                <li class="has-subnav">
                    <a href="<?= base_url();?>admin_zone/add_offer">
                       <i class="fa fa-folder-open fa-2x"></i>
                        <span class="nav-text">
                            Add Seoson Offer
                        </span>
                    </a>
                   
                </li>
                <li>
                    <a href="#">
                        <i class="fa fa-bar-chart-o fa-2x"></i>
                        <span class="nav-text">
                        Varify Shop Keeper
                        </span>
                    </a>
                </li>
                <li>
                    <a href="<?= base_url();?>admin_zone/add_sub_catogory">
                        <i class="fa fa-font fa-2x"></i>
                        <span class="nav-text">
                           Add Sub-category
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                       <i class="fa fa-table fa-2x"></i>
                        <span class="nav-text">
                            Tables
                        </span>
                    </a>
                </li>
                <li>
                   <a href="#">
                        <i class="fa fa-map-marker fa-2x"></i>
                        <span class="nav-text">
                            Maps
                        </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                       <i class="fa fa-info fa-2x"></i>
                        <span class="nav-text">
                            Documentation
                        </span>
                    </a>
                </li>
            </ul>

            <ul class="logout">
                <li>
                   <a href="#">
                         <i class="fa fa-power-off fa-2x"></i>
                        <span class="nav-text">
                            Logout
                        </span>
                    </a>
                </li>  
            </ul>
        </nav>