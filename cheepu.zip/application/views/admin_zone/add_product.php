<div class="container">
<a href="<?= base_url(); ?>seller/seller_dashboard" class="btn btn-light"><i class="fa fa-backward">Back</i></a>
<div class="card bg-primary col-md-5 ml-auto mr-auto mt-5">
	<div class="card-header text-white ml-auto mr-auto">
		<h4 class="display-4">Add Product</h4>
	</div>
	<div class="card-body ">
<form action="<?= base_url();?>admin_zone/add_product" method="post" enctype="multipart/form-data">
		<div class="form-group">
   			<label class="text-white" for="">Product Name</label>    
    		<input type="text" name="product_name" class="form-control " id="" placeholder="Product Name" value="<?= $product_name; ?>">
    	 <span class="invalid-feedback"></span>
  		</div>
    <div class="form-group">
        <label class="text-white" for="sku">SKU</label>    
        <input type="text" name="sku" class="form-control " id="" placeholder="SKU ID" value="<?= $sku; ?>">
       <span class="invalid-feedback"></span>
      </div>  
  		<div class="form-group">
   			<label for="" class="text-white">Select Sub-Category Type</label>    
				<select class="form-control" name="sub_cat_id">
					<?php foreach ($cat_name as $category ) : ?>
						<option value="<?= $category->sub_category_id; ?>"><?= $category->sub_category_name; ?></option>
					<?php endforeach; ?>
				</select>    		
    	 <span class="invalid-feedback"></span>
  		</div>
  		<div class="form-group">
  			<label for="" class="text-white">Image For Product</label>
   			<input type="file" name="userfile" class="form-control " id="" >
    	 <span class="invalid-feedback"></span>
  		</div>
      <div class="form-group">
        <label for="" class="text-white">Quantity or per Item</label>
        <select class="form-control" name="type">
            <option  class="form-control">---select----</option>
            <option value="100g" class="form-control">100g</option>
            <option value="500g" class="form-control">500g</option>
            <option value="1kg" class="form-control">kg</option>
            <option value="per-item" class="form-control">Per Item</option>
            <option value="per-dozen" class="form-control">Per Dozen</option>
        </select>
      </div>
      
      <div class="row">
        <div class="col">
      <div class="form-group">
        <label for="Common Name" class="text-white">Selling Price</label>
        <input type="number" name="s_p" class="form-control "  >
       <span class="invalid-feedback"></span>
      </div>          
        </div>
        <div class="col">
      <div class="form-group">
        <label for="Common Name" class="text-white">M.R.P.</label>
        <input type="number" name="m_r_p" class="form-control "  >
       <span class="invalid-feedback"></span>
      </div>          
        </div>
      </div>
      <div class="form-group">
        <label for="Common Name" class="text-white">Description</label>
        <textarea type="text" name="description" class="form-control "></textarea>
       <span class="invalid-feedback"></span>
      </div>

  		<div class="form-group btn-block"> 				
  			<input type="submit" class="btn btn-success" name="">	
  		</div>
  		</form>
   </div>
</div>	
</div>