<?= $this->session->userdata('name');?>
<?= $this->session->userdata('id'); ?>