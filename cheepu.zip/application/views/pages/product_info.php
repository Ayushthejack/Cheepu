        <div class="container mt-5 py-5" >
        	<div class="row">
               <div class="col-md-6 item-photo">
                    <img style="max-width:50%;" data-toggle="modal" data-target="#exampleModalCenter" src="<?= base_url()?>assets/img/products/<?=$product_image?>"  />
                </div>
                <div class="col-md-6" style="border:0px solid gray">
                    <!-- Datos del vendedor y titulo del producto -->
                    <h3><?= $product_name; ?></h3>    
                    
                    <!-- Precios -->
                    <h6 class="title-price"><small>SELLING PRICE</small></h6>
                    <h3 style="margin-top:0px;"><i class="fa fa-rupee"> </i><?= $s_p ?></h3>M.R.P. : <strike><?= $m_r_p ;?></strike>
        
                    <!-- Detalles especificos del producto -->
                    <div class="section">    
                    <div class="section" style="padding-bottom:20px;">
                        <h6 class="title-attr"><small>QUANTITY:-  </small></h6>                    
                        <div>
                            <div class="btn-minus"><span class="fa fa-minus"></span></div>
                            <input value="1" id="atcc<?=$product_id; ?>" pid="<?=$product_id; ?>"  min=1 disabled>
                            <div class="btn-plus"><span class="fa fa-plus"></span></div>
                        </div>
                    </div>                
        
                    <!-- Botones de compra -->
                    <div class="section" style="padding-bottom:20px;">
                        <button pid="<?=$product_id; ?>" id="atc<?=$product_id; ?>"  class="btn btn-primary btn-block addtocart">                         </span>Add To Cart</button>

                    </div>                                        
                </div>                              
        
                <div class="col-xs-9">
                    <ul class="menu-items">
                        <li class="active">Product Description</li>
                       
                    </ul>
                    <div style="width:100%;border-top:1px solid silver">
                        <p style="padding:15px;">
                            <small>
                                <?= $description; ?>
                            </small>
                    </div>
                </div>		
            </div>
        </div>  

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" style="background: url();">
            <img class="img-thumbnail" src="<?= base_url()?>assets/img/products/<?=$product_image?>"  />
      </div>

    </div>
  </div>
</div>