<h2>Trending <b>Offers</b></h2> 
<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?= base_url();?>assets/img/offer/1902001-apple-orchards_t1_460--banner.jpg" class="d-block w-100" alt="...">
    </div>
    <?php 
    $i = 1; 
    foreach ($offer as $offer ) : ?>
    <div class="carousel-item ">
      <img class="d-block w-100" src="<?= base_url();?>assets/img/offer/<?= $offer->offer_image; ?>" >
    </div>
  <?php  if ($i++ == 3) break; ?>  
  <?php endforeach; ?>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
 <div class="container">
  <h2>Best <b>Selling Products</b></h2>
  <div class="row mt-5">
    <?php foreach ($product as $product ) :  ?>
       <div class="w3-col l3 m3 s6">
  <!--        <a href="<?= base_url(); ?>pages/product_description/<?=$product->product_id; ?>"> -->
        <a style="text-decoration: none;" href="<?= base_url(); ?>pages/product_description/<?=$product->product_id; ?>" > 
          <div class="card mx-2 my-2" style="height: auto;">
            <img src="<?= base_url();?>assets/img/products/<?=$product->product_image;?>"  class="card-img-top" alt="..." width="23%" height="200" >
              <div class="card-body">
                 <div class="thumb-content" align="center">
                  <h4 ><?=$product->product_name; ?></h4>
                        <p style="color: red;font-size: 12px;"><i class="fa fa-rupee"  ></i><?=$product->s_p; ?>/<?=$product->type;?></p>
                         <form action="" method="post">
                  </div>  
              </div>  

            </div>
         </a> 
        </div>
    <?php endforeach; ?>
  </div>
</div>

<div id="carouselExampleFade" class="carousel slide " data-ride="carousel" data-interval="600000">
  <div class="carousel-inner" align="center">
    <div class="carousel-item active">
      <a href="#x1" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Gowardhan-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x2" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Gowardhan-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#3" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Gowardhan-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x4" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Gowardhan-ghee.jpg" alt="Image" style="max-width:20%;" /></a>      
    </div>
    <div class="carousel-item">
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Britannia-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Britannia-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Britannia-ghee.jpg" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/Britannia-ghee.jpg" alt="Image" style="max-width:20%;" /></a>
           
    </div>
    <div class="carousel-item">
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/matarj.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/matarj.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/matarj.jpg" alt="Image" style="max-width:20%;" /></a>
      <a href="#x" class="thumbnail"><img src="<?= base_url(); ?>assets/img/products/matarj.jpg" alt="Image" style="max-width:20%;" /></a>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleFade" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleFade" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
      </a>
  </div>
</div>