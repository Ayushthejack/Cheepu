<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_zone extends CI_Controller {
	
	public function dboard(){
		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/dboard");
		$this->load->view("templates/footer");
	}
	public function add_catogory(){
		if($this->session->userdata('sname')){
	if ($_SERVER['REQUEST_METHOD']=='POST') { 
		$data = [
			'cat_name'=>trim($_POST['cat_name']),
			'cat_name_err'=>''
				];
		if ($this->admin_model->add_category($data)) {
			# code...
		}			
					redirect('admin_zone/add_catogory');

		}else{

		$data = [
			'cat_name'=>'',
			'cat_name_err'=>''
				];
		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/add_catogory",$data);
		$this->load->view("templates/footer");
		}

		}else{
			redirect('seller/slogin');
		}

	}
	public function add_sub_catogory()
	{
	if($this->session->userdata('sname')){
		if ($_SERVER['REQUEST_METHOD']=='POST') {
			# code...
			$data = [
		 		'sub_category_name'=>trim($_POST['sub_category_name']),
				'cat_id'=>$_POST['cat_id'],				
				'sub_category_err'=>'',
				'cat_id_err'=>'',
				'sub_category_img'=>url_title($_FILES['userfile']['name']),
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_category($this->session->userdata('s_id'))								
		 	];	
		 		//after all vaidatiom
		 	 $new_name = time();
	 		 $a= strrpos($_FILES['userfile']['name'],".");
             $q=substr($_FILES['userfile']['name'],$a);
             $post_image =  $new_name.".".$q;
		$config['upload_path']='./assets/img/seller/subCat/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '99000';
        $config['max_width'] = '9500';
        $config['max_height'] = '9500';
        $a=  strrpos($_FILES['userfile']['name'],".");
             $q=  substr($_FILES['userfile']['name'],$a);
             $a = strrev($_FILES['userfile']['name']);
             $b = strrpos($_FILES['userfile']['name'],".");
             $p = substr($a,strlen($b)+1);
             $o = url_title(strrev($p));

             $post_image =	$o.$q;

        $config['file_name'] = $post_image;
        $this->load->library('upload',$config);	
        if(!$this->upload->do_upload()){
            $errors = array('error'=> $this->upload->display_errors());
            $post_image = 'noimage.jpg';
           die(print_r($errors));
            
          }else{
          		$this->admin_model->add_sub_category($data);
		 	$data = [
		 		'sub_category_name'=>'',
				'cat_id'=>'',					
				'sub_category_err'=>'',
				'cat_id_err'=>'',
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_category($this->session->userdata('s_id'))
		 		];
          }
		 		redirect('admin_zone/add_sub_catogory');
		}else{
			#load the form normally blank
		 $data = [
		 		'sub_category_name'=>'',
				'cat_id'=>'',					
				'sub_category_err'=>'',
				'cat_id_err'=>'',
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_category($this->session->userdata('s_id'))								
		 	];	
		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/add_sub_catogory",$data);
		$this->load->view("templates/footer");
		}
				}else{
			redirect('seller/slogin');
		}
	}
	public function add_product()
	{		
	if($this->session->userdata('sname')){	
		if($_SERVER['REQUEST_METHOD']=='POST') {
			
			$data = [
				'product_name'=>trim($_POST['product_name']),
				'sub_cat_id'=>trim($_POST['sub_cat_id']),
				'sku'=>	trim($_POST['sku']),			
				'product_image'=>url_title($_FILES['userfile']['name']),
				'type'=>trim($_POST['type']),
				's_p'=>$_POST['s_p'],
				'm_r_p'=>$_POST['m_r_p'],
				'description'=>$_POST['description'],
				'product_name_err'=>'',
				'sub_cat_id_err'=>'',
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_sub_category()					
				];
		//data is coming
			 $new_name = time();
	 		 $a= strrpos($_FILES['userfile']['name'],".");
             $q=substr($_FILES['userfile']['name'],$a);
             $post_image =  $new_name.".".$q;
		$config['upload_path']='./assets/img/products/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '99000';
        $config['max_width'] = '9500';
        $config['max_height'] = '9500';
        $a=  strrpos($_FILES['userfile']['name'],".");
             $q=  substr($_FILES['userfile']['name'],$a);
             $a = strrev($_FILES['userfile']['name']);
             $b = strrpos($_FILES['userfile']['name'],".");
             $p = substr($a,strlen($b)+1);
             $o = url_title(strrev($p));

             $post_image =	$o.$q;

        $config['file_name'] = $post_image;
        $this->load->library('upload',$config);	
        if(!$this->upload->do_upload()){
            $errors = array('error'=> $this->upload->display_errors());
            $post_image = 'noimage.jpg';
           die(print_r($errors));
            
          }else{
		//calling model after validation of data
		$this->admin_model->add_product();				
		 	$data = [
		 		'sku'=>'',
				'product_name'=>'',
				'sub_cat_id'=>'',				
				'product_image'=>'',
				'type'=>'',
				'Price'=>'',	
				'product_name_err'=>'',
				'sub_cat_id_err'=>'',
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_sub_category()					
				];

		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/add_product",$data);
		$this->load->view("templates/footer");
           	}
		//validation of data		       
			
		}else{
			//load the form
			$data = [
				'sku'=>	'',
				'product_name'=>'',
				'sub_cat_id'=>'',
				'product_image'=>'',
				'product_name_err'=>'',
				'cat_id_err'=>'',
				'product_image_err'=>'',
				'cat_name'=> $this->admin_model->load_sub_category()					
				];	

		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/add_product",$data);
		$this->load->view("templates/footer");	
		}
				}else{
			redirect('seller/slogin');
		}
	}
	public function add_offer()
	{
		# code...
		if ($_SERVER['REQUEST_METHOD']=='POST') { 
		$data = [
					'offer_image' => $_FILES['userfile']['name'],
					'offer_image_err'=>'' 
				];
			if (!empty($data['offer_image'] )) {
				# code...
				//upload the image to target folder
		$config['upload_path']='./assets/img/offer/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '99000';
        $config['max_width'] = '9500';
        $config['max_height'] = '9500';
        $config['file_name'] = $_FILES['userfile']['name'];
        $this->load->library('upload',$config);	
        if(!$this->upload->do_upload()){
            $errors = array('error'=> $this->upload->display_errors());
            $post_image = 'noimage.jpg';
           die(print_r($errors));		
       }

					$this->admin_model->add_offer($data);
			}else
			 {
			 	//load with errors
			 	$data['offer_image_'] = "NO image selected"; 
			 	$this->load->view("templates/sheader");
				$this->load->view("admin_zone/add_offer",$data);
				$this->load->view("templates/footer"); 
			 }

		}else{


		$data = [
					'offer_image' => '',
					'offer_image_err'=>''
				];
		$this->load->view("templates/sheader");
		$this->load->view("admin_zone/add_offer",$data);
		$this->load->view("templates/footer");

		}

	}
	 public function load_offer()
	{
		# code...
		return load_offer();

	}
}