<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	
	public function register(){
			$method = $_SERVER['REQUEST_METHOD'];

			if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
			} else {

			$check_auth_client = $this->MyModel->check_auth_client();
			
			if($check_auth_client == true){
				$params = $_REQUEST;
		        
		        $username = $params['username'];
		        $password = $params['password'];

		        	
		        $response = $this->MyModel->register($username,$password);
				echo $response;
				json_output($response['status'],$response);
			}
		}
	}	
	public function login()
	{
		$method = $_SERVER['REQUEST_METHOD'];

		if($method != 'POST'){
			json_output(400,array('status' => 400,'message' => 'Bad request.'));
		} else {

			$check_auth_client = $this->MyModel->check_auth_client();
			
			if($check_auth_client == true){
				$params = $_REQUEST;
		        
		        $username = $params['username'];
		        $password = $params['password'];

		        	
		        $response = $this->MyModel->login($username,$password);
				echo $response;
				json_output($response['status'],$response);
			}
		}
	}
	 public function offer()
	{
		# code...
		$method = $_SERVER['REQUEST_METHOD'];
			if ($method!='GET' ) {
				# code...

			json_output(400,array('status' => 400,'message' => 'Bad request.'));	
				}else{
			$status = 200;				
			$offers = 	$this->MyModel->get_offer();
			json_output($status,$offers);			
			}
	}
	public function category($value='')
	{
		$check_auth_client = $this->MyModel->check_auth_client();
		if ($check_auth_client) {
			$status = 200;				
			$offers = 	$this->MyModel->get_offer();
			json_output($status,$offers);			
		}
	}
	 public function product($value='')
	 {
	 	# code...
		$check_auth_client = $this->MyModel->check_auth_client();
		if ($check_auth_client) {
			$status = 200;				
			$offers = 	$this->MyModel->get_all_products();
			json_output($status,$offers);
			}
	 }
	public function subCategory($value='')
	 {
	 	# code...
	 	$check_auth_client = $this->MyModel->check_auth_client();
		if ($check_auth_client) {
			$status = 200;		
			$offers = 	$this->MyModel->get_offer();
			json_output($status,$offers);			
		}	
	 } 
}
