<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cart extends CI_Controller {
		public function basket($value='')
		{
			# code.. 
			$data = [
		 		'name'=> '',
		 		'mobile'=>'',
		 		'password'=>'',
		 		'email'=>'',
		 		'email_err'=>'',
		 		'name_err'=> '',
		 		'mobile_err'=>'',
		 		'password_err'=>'',
		 		'product'=>$this->pages_model->load_banner(),
		 		'offer'=>$this->admin_model->load_offer()		 		
		 	];

			$this->load->view("templates/header",$data);			
			$this->load->view("templates/cdnhead");
			$data =  [
				'cartpro'=>$this->pages_model->product_from_cart()
			 		];
			$this->load->view("cart/basket",$data);
			$this->load->view("templates/footer");

		}
	public function removeFromCart($cart_id)
		{
			# code...
			$result = $this->pages_model->removeFromCart($cart_id);

			echo json_encode(array('status'=>$cart_id));
			
		}
	public function checkout()
			{			$data = [
		 		'name'=> '',
		 		'mobile'=>'',
		 		'password'=>'',
		 		'email'=>'',
		 		'email_err'=>'',
		 		'name_err'=> '',
		 		'mobile_err'=>'',
		 		'password_err'=>'',
		 		'product'=>$this->pages_model->load_banner(),
		 		'offer'=>$this->admin_model->load_offer()		 		
		 	];
				# code...
				$this->load->view('templates/header',$data);
				$data = [
					'user'=>$this->pages_model->get_user_info(),
					'products'=>$this->pages_model->product_from_cart()
						] ;


				$this->load->view("cart/checkout",$data);
				$this->load->view('templates/footer');

			}		

	}
?>
