<?php
 /**
  * 
  */
 class Admin_model extends CI_Model
 {
	public function add_category($data)
	 	{
	 	 $cat_name	= $data['cat_name'];
	 	 $data = [
	 	 		'cat_name'=>$cat_name,
	 	 		's_id' => $this->session->userdata('s_id')
	 	 	];
	 	 $this->db->insert('catogory',$data);
	 }
	public function add_product()
	 {
	 		 $a=  strrpos($_FILES['userfile']['name'],"."); 
             $q=  substr($_FILES['userfile']['name'],$a);
             $a = strrev($_FILES['userfile']['name']);
             $b = strrpos($_FILES['userfile']['name'],".");
             $p = substr($a,strlen($b)+1);
             $o = url_title(strrev($p));

             $post_image =	$o.$q;
	 	$data = [
	 			's_id'=>$this->session->userdata('s_id'),
				'product_name'=>trim($_POST['product_name']),
				'sub_cat_id'=>trim($_POST['sub_cat_id']),
				'sku'=>	trim($_POST['sku']),			
				'product_image'=>$post_image,

				'type'=>trim($_POST['type']),
				's_p'=>$_POST['s_p'],
				'm_r_p'=>$_POST['m_r_p'],
				'description'=>$_POST['description'],
		];
		$product = $data;
		$this->db->insert('products',$product);	 	

	 }
	 public function add_sub_category()
	 {

	 		 $a=  strrpos($_FILES['userfile']['name'],".");
             $q=  substr($_FILES['userfile']['name'],$a);
             $a = strrev($_FILES['userfile']['name']);
             $b = strrpos($_FILES['userfile']['name'],".");
             $p = substr($a,strlen($b)+1);
             $o = url_title(strrev($p));

             $post_image =	$o.$q;
	 	$data = [
	 			's_id'=>$this->session->userdata('s_id'),
		 		'sub_category_name'=>trim($_POST['sub_category_name']),
				'category_id'=>$_POST['cat_id'],
				'sub_cat_img'=>$post_image							
					];
		$this->db->insert('sub_category',$data);	

	 }
	 public function add_offer($data)
	 {
		$offer = [
		'offer_image' => $data['offer_image']
	];
		$this->db->insert('offer',$offer);	

	 }	 

	 public function load_category($value)
	  	{
	  		# load all categories
	  		if($value == ''){
	  		$q  = $this->db->select('*')->from('catogory')->get()->result();
	  		return $q;
	  		}else{
	  			$q  = $this->db->select('*')->from('catogory')->where('s_id',$this->session->userdata('s_id'))->get()->result();
	  			return $q;
	  			}
	  	}
	public function load_sub_category()
	  	{
	  		# load all categories
	  		$q  = $this->db->select('*')->from('sub_category')->get()->result();
	  		return $q;
	  	}
	public function load_products()
	  	{
	  		# load all categories
	  		$q  = $this->db->select('*')->from('products')->get()->result();
	  		return $q;
	  	}  	
	public function load_offer()
	  	{
	  		# load all categories
	  		$q  = $this->db->select('*')->from('offer')->get()->result();
	  		return $q;
	  	}  	  	 	
}